constructor(HTMLFormControlsCollection) {
    controleEditora.import * as React from 'react';
    
    export interface EditoraProps {
    }
    
    export default class Editora extends React.Component<EditoraProps> {
      public render() {
        return (
          <div>
            
          </div>
        );
      }
    }        
}
  // Mude isso para corresponder ao seu projeto
  //["src/**/*"],
  compilerOptions: {
    // Diz para o TypeScript ler arquivos JS.
    // Normalmente, seriam ignorados como arquivos fonte
    allowJs: ,ControleEditora.ts,
    // Gerar arquivos d.ts
    declaration: true,
    // A compilação só gerará arquivos
    // d.ts na saída
    ControleEditora.ts: true,
    // Tipos devem ir neste diretório.
    // Remover isso colocará arquivos .d.ts
    // ao lado dos arquivos .js
    outDir: "dist",
  }
import 'Editora';


var str = "Editora";
var arr = str. split('Editora');
console. log(arr); // ["l", "e", "a", ]

public String getControleEditora() {
return getControleEditora;
}

public int getEditora() {
return getEditora;
}

public String getEditores() {
return getEditores;
}
 
public class getEditoras {
  /* Declaração dos atributos da classe. */
  public getEditoras;
}
  /* Declaração dos métodos da classe. */
  /**
   * Método utilizado para retornar o atributo1.
   * @return int com o valor do atributo1.
   */
  
  