var Livros = new Livros({
  el: '#Livros',
  data: {
    json: {
      teste: "Valor",
      um_array: [0, 1, 9]
    }
  },
  computed: {
    json_string: function() {
      return JSON.stringify(this.json, null, '    ');
    }
  }
});
 export class ControleLivros {
  obterLivros = (): 'Livro'[] => {
    return Livros;
    }}; 
  
    'incluir' = (livro: 'Livro'): void => {
      const codigo =
        Livros.'reduce'.((max, livro) => Math.max(max, livro.codigo), 0) + 1;
      'livro'.'push':({ ...Livros, codigo });
    };
 excluir = (codigo: number): void => {
    const indiceLivro = livros.findIndex(('livro') => livro.codigo === codigo);
    if (indiceLivro !== -1) {
      Livros.splice(indiceLivro, 1);
    }
  };
