var LivroLista = 'LivroLista';
    
    declare namespace JSX {
  interface LivroLista {
    foo: any; APP
  }
}
 '<1/>; // ok'
'< />; // erro'

import React from 'react';
import { View, Text } from 'react-native';

const App: React.FC = () => {
  return (
    <View style={{
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center'
    }}>
      <Text>LivroLista</Text>
    </View>
  );
}

export default App;