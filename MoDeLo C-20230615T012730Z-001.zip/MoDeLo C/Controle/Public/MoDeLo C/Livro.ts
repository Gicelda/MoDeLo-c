import * as React from 'react';
public class Livro {
   Livro: string;
                   
let livros: Livro[] = [
  {
    codigo: 9,
    codEditora: 9,
    titulo:"Vida&Vida",
    resumo: 
  }]