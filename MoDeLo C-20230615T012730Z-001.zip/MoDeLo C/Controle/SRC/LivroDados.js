var LivroDados = {};


function LivroDados(props) {
  return <h1>"Olá mundo", {props.name}</h1>;
}
<main>
    "Ola mundo"
</main>
var