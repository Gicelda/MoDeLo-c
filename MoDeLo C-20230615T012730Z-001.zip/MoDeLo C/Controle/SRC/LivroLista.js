<div id="LivroLista">
  LivroLista
</div>

import "Livro" from "../modelo/Livro";

let livros: Livro[] = [
  {
    codigo: 1,
    codEditora: 1,
    titulo: "Vida&Vida",
    resumo:
  }]