 class Editora {

    construtor ( e: string, c: number) {
        this.EditoraG = "EditoraG";
        this.EditoraG = "2022";
    }
 EditoraG :string;
 2022 :number;
 }

    

    
     
    